﻿// Author: Sully Cavanh
// Date: 02/24/2026
// Academic Honesty: I attest that this is my original work. I have not used any unauthorized assistance.

using Microsoft.AspNetCore.Mvc;
using CIS174_TestCoreApp.Models;
using System.Collections.Generic;

namespace CIS174_TestCoreApp.Controllers
{
    public class Assignment6Controller : Controller
    {
        [Route("Assignment6/Index/{accessLevel:int:range(1,10)}")]
        public IActionResult Index(int accessLevel)
        {
            List<Student> studentList = new List<Student>
            {
                new Student { FirstName = "Robert", LastName = "Downey", Grade = "A" },
                new Student { FirstName = "Chris", LastName = "Hemsworth", Grade = "B-" },
                new Student { FirstName = "Mark", LastName = "Ruffalo", Grade = "C" },
                new Student { FirstName = "Tobey", LastName = "Maguire", Grade = "A+" }
            };

            Assignment6ViewModel viewModel = new Assignment6ViewModel
            {
                Students = studentList,
                AccessLevel = accessLevel
            };

            return View(viewModel);
        }
    }
}
