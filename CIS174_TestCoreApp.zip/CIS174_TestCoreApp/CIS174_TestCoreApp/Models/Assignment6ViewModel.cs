﻿// Author: Sully Cavanh
// Date: 02/24/2026
// Academic Honesty: I attest that this is my original work. I have not used any unauthorized assistance.

using System.Collections.Generic;

namespace CIS174_TestCoreApp.Models
{
    public class Assignment6ViewModel
    {
        public List<Student> Students { get; set; }
        public int AccessLevel { get; set; }
    }
}
