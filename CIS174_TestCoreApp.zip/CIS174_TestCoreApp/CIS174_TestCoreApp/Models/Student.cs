﻿// Author: Sully Cavanh
// Date: 02/24/2026
// Academic Honesty: I attest that this is my original work. I have not used any unauthorized assistance.

namespace CIS174_TestCoreApp.Models
{
    public class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Grade { get; set; }
    }
}
