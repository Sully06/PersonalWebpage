using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CIS174_TestCoreApp.Views.Assignment6
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
