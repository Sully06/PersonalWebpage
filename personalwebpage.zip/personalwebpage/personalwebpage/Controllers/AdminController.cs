﻿namespace personalwebpage.Controllers
{
    using Microsoft.AspNetCore.Mvc;

    namespace MyWebsite.Controllers
    {
        public class AdminController : Controller
        {
            public IActionResult Index()
            {
                return View();
            }
        }
    }
}

//that is my simplest admin page by the way