﻿using Microsoft.AspNetCore.Mvc;

namespace YourProjectName.Controllers
{
    public class AssignmentController : Controller
    {
        //Default Routing Page
        public IActionResult DefaultPage()
        {
            return View();
        }
        //Custom Routing Rules Page
        //This will be accessed by a special rule in Program.cs
        public IActionResult CustomRulePage()
        {
            return View();
        }

        //Custom Routing Attribute Page
        //The route attribute overrides other rules.
        [Route("my-cool-attribute-page")]
        public IActionResult AttributePage()
        {
            return View();
        }
    }
}
