/* 
I have not used unauthorized assistance to my coding. 
This is an important declaration for my assignment.
*/

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "myCustomRoute",
    pattern: "custom-route-example",
    defaults: new { controller = "Assignment", action = "CustomRulePage" });

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
