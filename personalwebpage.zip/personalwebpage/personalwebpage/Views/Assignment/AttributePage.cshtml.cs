using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace personalwebpage.Views.Assignment
{
    public class AttributePageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
