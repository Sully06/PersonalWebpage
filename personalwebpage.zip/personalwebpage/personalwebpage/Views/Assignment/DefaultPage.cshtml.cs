using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace personalwebpage.Views.Assignment
{
    public class DefaultPageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
